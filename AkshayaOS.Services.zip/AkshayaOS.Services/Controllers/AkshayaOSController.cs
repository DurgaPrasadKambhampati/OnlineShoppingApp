﻿using AkshayaOS.DAL;
using AkshayaOS.DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace AkshayaOS.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AkshayaOSController : Controller
    {
        Repository repository;
        public AkshayaOSController()
        {
            repository = new Repository();
        }


        [HttpGet]
        public JsonResult GetProducts()
        {
            List<Models.Product> products = new List<Models.Product>();
            try
            {
                var pl = repository.GetProducts();

                foreach (var item in pl)
                {
                    Models.Product temp = new Models.Product();
                    temp.PictureFileLocation = item.PictureFileLocation;
                    temp.Price = item.Price;
                    temp.Description = item.Description;
                    temp.Discount = item.Discount; 
                    temp.ProductId = item.ProductId;
                    temp.ProductName = item.ProductName;
                    temp.AvailablePieces = item.AvailablePieces;
                     products.Add(temp);
                }

            }
            catch (Exception)
            {
                products = null;
            }
            return Json(products);
        }

        [HttpPost]
        public JsonResult AddProduct(Models.Product prod)
        {
            Product p = new Product();
            bool status = false;
            try
            {
                p.ProductId = prod.ProductId;
                p.ProductName = prod.ProductName;
                p.Description = prod.Description;
                p.Price = prod.Price;
                p.Discount = prod.Discount;
                p.AvailablePieces = prod.AvailablePieces;
                p.PictureFileLocation=prod.PictureFileLocation;
                status = repository.AddProduct(p);
            }
            catch (Exception)
            {
                status = false;
            }
            return Json(status);
        }


        [HttpPost]
        public JsonResult ValidateUser(Models.User us)
        {
            int res = 0;
            try
            {
                User u = new User();
                u.UserId = us.UserId;
                u.Password = us.Password;
                res = repository.ValidateUser(u);
            }
            catch (Exception e)
            {
                res = 0;
            }
            return Json(res);
        }

        [HttpGet]
        public JsonResult GetAllUsers()
        {
            List<User> users = new List<User>();
            try
            {
                users = repository.GetAllUsers();
            }
            catch (Exception)
            {

                users = null;
            }
            return Json(users);
        }

        [HttpGet]
        public JsonResult GetUserByUserNo(int uNo)
        {
            Models.User user = new Models.User();
            try
            {
                var u = repository.GetUserByUserNo(uNo);
                user.UserId = u.UserId;
                user.Password = u.Password;
                user.UserName = u.UserName;
                user.MobileNumber = u.MobileNumber;
                user.UserNo = u.UserNo;
                user.Address = u.Address;
            }
            catch (Exception)
            {

                user = null;
            }
            return Json(user);
        }

        [HttpPost]
        public JsonResult ValidateDM(Models.DeliveryMan dm)
        {
            int res = 0;
            try
            {
                DeliveryMan u = new DeliveryMan();
                u.Dmid = dm.Dmid;
                u.Password = dm.Password;
                res = repository.validateDM(u);
            }
            catch (Exception e)
            {
                res = 0;
            }
            return Json(res);
        }

        [HttpGet]
        public JsonResult GetAllDeliveryMansDetails()
        {
            List<Models.DeliveryMan> deliveryMens = new List<Models.DeliveryMan>();
            try
            {
                var dms = repository.GetAllDeliveryMansDetails();
                foreach (var item in dms)
                {
                    Models.DeliveryMan dm = new Models.DeliveryMan();
                    dm.Dmid = item.Dmid;
                    dm.Password = item.Password;
                    dm.DeliveryManNo = item.DeliveryManNo;
                    dm.Dmname = item.Dmname;
                    dm.MobileNumber = item.MobileNumber;
                    deliveryMens.Add(dm);
                }
            }
            catch (Exception)
            {

                deliveryMens = null;
            }
            return Json(deliveryMens);
        }

        [HttpGet]
        public JsonResult GetDMCount()
        {
            int count = 0;
            try
            {
                count = repository.GetDMCount();
            }
            catch (Exception)
            {

                count = 0;
            }
            return Json(count);
        }

        [HttpGet]
        public JsonResult validateAdmin(string aid,string pass)
        {
            bool status = false;
            try
            {
                status = repository.ValidateAdmin(aid, pass);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpPost]
        public JsonResult AddUser(Models.User user)
        {
            bool status = false;
            try
            {
                var u = new User();
                u.UserId = user.UserId;
                u.UserNo = user.UserNo;
                u.UserName = user.UserName;
                u.Password = user.Password;
                u.MobileNumber = user.MobileNumber;
                u.Address = user.Address;
                status = repository.AddUser(u);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }
        [HttpPost]
        public JsonResult PurchaseProduct(Models.PurchaseDetail pd)
        {
            bool status = false;
            PurchaseDetail p = new PurchaseDetail();
            try
            {
                p.PurchaseId = pd.PurchaseId;
                p.ProductId = pd.ProductId;
                p.UserNo = pd.UserNo;
                p.OrderedDate = pd.OrderedDate;
                p.Otp = pd.Otp;
                p.ShippingAddress = pd.ShippingAddress;
                p.DeliveryManNo = pd.DeliveryManNo;
                p.Status = pd.Status;
                p.TotalAmount= pd.TotalAmount;
                p.Quantity = pd.Quantity;
                status = repository.PurchaseProduct(p);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpGet]
        public JsonResult GetPurchaseDetailsBYUno(int uno)
        {
            List<Models.PurchaseDetail> purchaseDetails = new List<Models.PurchaseDetail>();
            try
            {
                var pds = repository.GetPurchaseDetailsBYUserNo(uno);
                
                foreach (var item in pds)
                {
                    Models.PurchaseDetail p = new Models.PurchaseDetail();
                    p.PurchaseId=item.PurchaseId;
                    p.UserNo=item.UserNo;
                    p.DeliveryManNo=item.DeliveryManNo;
                    p.ProductId=item.ProductId;
                    p.TotalAmount=item.TotalAmount;
                    p.Otp=item.Otp;
                    p.Quantity=item.Quantity;
                    p.Status=item.Status;
                    p.OrderedDate=item.OrderedDate;
                    p.ShippingAddress=item.ShippingAddress;
                    purchaseDetails.Add(p);
                }

            }
            catch (Exception)
            {

                purchaseDetails = null;
            }
            return Json(purchaseDetails);
        }

        [HttpDelete]
        public JsonResult CancleOrder(int pid)
        {
            bool status = false;
            try
            {
                status = repository.CancleOrder(pid);
            }
            catch (Exception)
            {

                status = true;
            }
            return Json(status);
        }

        [HttpPut]
        public JsonResult UpdateUserName(int uno,string uname)
        {
            bool status;
            try
            {
                status = repository.UpdateUserName(uno, uname);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpPut]
        public JsonResult UpdateMobileNo(int uno, decimal mobileNumber)
        {
            bool status;
            try
            {
                status = repository.UpdateMobileNo(uno, mobileNumber);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpPut]
        public JsonResult UpadateAddress(int uno, string address)
        {
            bool status;
            try
            {
                status = repository.UpdateAddress(uno, address);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpDelete]
        public JsonResult DeleteProduct(int pid)
        {
            bool status = false;
            try
            {
                status = repository.DeleteProduct(pid);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpGet]
        public JsonResult GetProductByPid(int pid)
        {
            Models.Product product = new Models.Product();
            try
            {
                var p = repository.GetProductByPid(pid);
                product.ProductId = p.ProductId;
                product.ProductName = p.ProductName;
                product.Price = p.Price;
                product.Description = p.Description;
                product.PictureFileLocation = p.PictureFileLocation;
                product.Discount = p.Discount;
                product.AvailablePieces = p.AvailablePieces;
            }
            catch (Exception)
            {

                product=null;
            }
            return Json(product);
        }

        [HttpPut]
        public JsonResult EditProduct(Models.Product product)
        {
            bool status = false;
            Product p = new Product();
            try
            {
                p.ProductId = product.ProductId;
                p.ProductName = product.ProductName;
                p.Description = product.Description;
                p.Discount = product.Discount;
                p.PictureFileLocation= product.PictureFileLocation;
                p.Price = product.Price;
                p.AvailablePieces = product.AvailablePieces;
                status = repository.EditProduct(p);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpPost]
        public JsonResult AddAdmin(Admin ad)
        {
            bool status = false;
            try
            {
                status = repository.AddAdmin(ad);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpGet]
        public JsonResult GetAllPurchaseDetails()
        {
            List<Models.PurchaseDetail> purchaseDetails = new List<Models.PurchaseDetail>();
            try
            {
                var pdl = repository.GetAllPurchaseDetails();
                foreach (var p in pdl)
                {
                    Models.PurchaseDetail temp = new Models.PurchaseDetail();
                    temp.ProductId = p.ProductId;
                    temp.DeliveryManNo = p.DeliveryManNo;
                    temp.PurchaseId = p.PurchaseId;
                    temp.TotalAmount = p.TotalAmount;
                    temp.Otp = p.Otp;
                    temp.Quantity = p.Quantity;
                    temp.ShippingAddress = p.ShippingAddress;
                    temp.Status = p.Status;
                    temp.UserNo = p.UserNo;
                    temp.OrderedDate = p.OrderedDate;
                    purchaseDetails.Add(temp);
                }
            }
            catch (Exception)
            {

                purchaseDetails = null;
            }
            return Json(purchaseDetails);
        }

        [HttpPost]
        public JsonResult AddNewDeliveryMan(Models.DeliveryMan dm)
        {
            bool status = false;
            DeliveryMan deliveryMan = new DeliveryMan();
            try
            {
                
                deliveryMan.Dmid = dm.Dmid;
                deliveryMan.MobileNumber = dm.MobileNumber;
                deliveryMan.Dmname = dm.Dmname;
                deliveryMan.Password = dm.Password;
                deliveryMan.DeliveryManNo = dm.DeliveryManNo;
                status = repository.AddNewDeliveryMan(deliveryMan);
            }
            catch (Exception ex)
            {
                status = false;
            }
            return Json(status);
        }

        [HttpGet]
        public JsonResult GetPurchaseDetailsByDMno(int dmno)
        {
            List<Models.PurchaseDetail> res = new List<Models.PurchaseDetail>();
            try
            {
                var raw = repository.GetAllPurchaseDetails();
                foreach (var p in raw)
                {
                    if(p.DeliveryManNo == dmno)
                    {
                        Models.PurchaseDetail temp = new Models.PurchaseDetail();
                        temp.PurchaseId = p.PurchaseId;
                        temp.DeliveryManNo = p.DeliveryManNo;
                        temp.OrderedDate = p.OrderedDate;
                        temp.TotalAmount = p.TotalAmount;
                        temp.UserNo = p.UserNo;
                        temp.Status = p.Status;
                        temp.Otp = p.Otp;
                        temp.ProductId = p.ProductId;
                        temp.Quantity = p.Quantity;
                        temp.ShippingAddress = p.ShippingAddress;
                        res.Add(temp);
                    }
                }
            }
            catch (Exception)
            {

                res = null;
            }
            return Json(res);
        }
        [HttpPut]
        public JsonResult updateDeliveryStatus(int pid)
        {
            bool status = false;
            try
            {
                status = repository.updateDeliveryStatus(pid);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpDelete]
        public JsonResult DeleteUser(Models.User userObj)
        {
            bool status = false;
            
            try
            {
                User user = new User();
                user.UserNo = userObj.UserNo;
                user.UserId = userObj.UserId;
                user.UserName = userObj.UserName;
                user.MobileNumber = userObj.MobileNumber;
                user.Password = userObj.Password;
                user.Address = userObj.Address;
                status = repository.DeleteUser(user);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        [HttpDelete]
        public JsonResult DeleteDeliveryMan(int dmNo)
        {
            bool status = false;
            try
            {
                status = repository.DeleteDeliveryMan(dmNo);
            }
            catch (Exception)
            {

                status = false;
            }
            return Json(status);
        }

        //[HttpPost]
        //public JsonResult ScanFingerprint()
        //{
        //    try
        //    {
        //        // Connect to the fingerprint device
        //        ZKFPEngX fpEngine = new ZKFPEngX();
        //        fpEngine.InitEngine();

        //        // Start capturing a fingerprint
        //        fpEngine.BeginEnroll();
        //        fpEngine.BeginCapture();
        //        var obj = fpEngine.GetTemplate();


        //        // Get the captured fingerprint image
        //        fpEngine.GetFingerImage(obj);

        //        // Extract the template from the fingerprint image
        //        var o = fpEngine.GetTemplateAsString();

        //        // Store the template in a database or send it to another service for authentication
        //        // ...

        //        // Clean up
        //        fpEngine.CancelEnroll();

        //        Console.WriteLine(o);
        //        return Json(o);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(BadRequest(ex.InnerException.Message));
        //    }
        //}
    }
}
