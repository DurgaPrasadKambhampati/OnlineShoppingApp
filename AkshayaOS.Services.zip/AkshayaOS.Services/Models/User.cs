﻿namespace AkshayaOS.Services.Models
{
    public class User
    {
        public int UserNo { get; set; }
        public string UserName { get; set; } = null!;
        public string UserId { get; set; } = null!;
        public string Password { get; set; } = null!;
        public decimal MobileNumber { get; set; }

        public string Address { get; set; } = null!;
    }
}
