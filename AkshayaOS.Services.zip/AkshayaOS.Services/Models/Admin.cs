﻿namespace AkshayaOS.Services.Models
{
    public class Admin
    {
        public string UserId { get; set; } = null!;
        public string AdminName { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
