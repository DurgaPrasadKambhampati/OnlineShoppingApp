﻿namespace AkshayaOS.Services.Models
{
    public class DeliveryMan
    {
        public int DeliveryManNo { get; set; }
        public string Dmname { get; set; } = null!;
        public string Dmid { get; set; } = null!;
        public string Password { get; set; } = null!;
        public decimal MobileNumber { get; set; }
    }
}
