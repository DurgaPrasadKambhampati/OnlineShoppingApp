﻿using AkshayaOS.DAL.Models;
using System.Linq;
using System.Linq.Expressions;

namespace AkshayaOS.DAL
{
    public class Repository
    {
        AkshayaOSContext context;

        public Repository()
        {
            context = new AkshayaOSContext();
        }
        public bool AddAdmin(Admin ad)
        {
            bool status = false;
            try
            {
                context.Admins.Add(ad);
                context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }

        public bool ValidateAdmin(string userId,string password)
        {
            bool status = false;
            try
            {
                var ad = context.Admins.Find(userId);
                if (ad.Password == password)
                    status = true;
                else
                    status = false;
            }
            catch (Exception)
            {
                status=false;
            }
            return status;
        }

        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();
            try
            {
                users = context.Users.ToList();
            }
            catch (Exception)
            {

                users = null;
            }
            return users;
        }

        public User GetUserByUserNo(int uNo)
        {
            User user = new User();
            try
            {
                user = context.Users.Find(uNo);
            }
            catch (Exception)
            {

                user = null;
            }
            return user;
        }

        public int ValidateUser(User obj)
        {
            int res = 0;
            try
            {
                List<User> users = new List<User>();
                users = context.Users.ToList();
                foreach (User user in users)
                {
                    if(user.UserId == obj.UserId && user.Password == obj.Password)
                    {
                        res = user.UserNo;
                    }
                }
            }
            catch (Exception)
            {

               res = 0;
            }
            return res;
        }

        public int validateDM(DeliveryMan obj)
        {
            int res = 0;
            try
            {
                List<DeliveryMan> dms = new List<DeliveryMan>();
                dms = context.DeliveryMans.ToList();
                foreach (DeliveryMan user in dms)
                {
                    if (user.Dmid== obj.Dmid && user.Password == obj.Password)
                    {
                        res = user.DeliveryManNo;
                    }
                }
            }
            catch (Exception)
            {

                res = 0;
            }
            return res;

        }

        public List<DeliveryMan> GetAllDeliveryMansDetails()
        {
            List<DeliveryMan> deliveryMens = new List<DeliveryMan>();
            try
            {
                deliveryMens = context.DeliveryMans.ToList();
            }
            catch (Exception)
            {

                deliveryMens = null;
            }
            return deliveryMens;
        }

        public int GetDMCount()
        {
             int count = 0;
            try
            {
                count = context.DeliveryMans.Count();
            }
            catch (Exception)
            {

                count = 0;
            }
            return count;
        }

        public List<Product> GetProducts()
        {
            List<Product> products = new List<Product>();
            try
            {
                products = context.Products.ToList();

            }
            catch (Exception)
            {

                products = null;
            }
            return products;
        }
        public bool AddProduct(Product prod)
        {
            bool status = false;
            try
            {
                context.Products.Add(prod);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool AddUser(User user)
        {
            bool status = false;
            try
            {
                context.Users.Add(user);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool PurchaseProduct(PurchaseDetail pd)
        {
            bool status = true;
            try
            {
                context.PurchaseDetails.Add(pd);
                var products = context.Products.ToList();
                foreach (var product in products)
                {
                    if (product.ProductId == pd.ProductId)
                        product.AvailablePieces -= pd.Quantity;
                }   
                context.SaveChanges();
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public List<PurchaseDetail> GetPurchaseDetailsBYUserNo(int uno)
        {
            List<PurchaseDetail> list = new List<PurchaseDetail>();
            try
            {
                list = (from p in context.PurchaseDetails
                       where p.UserNo == uno
                       select p).ToList();

            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }

        public bool CancleOrder(int pid)
        {
            bool status = false;
            try
            {
                var pd = context.PurchaseDetails.Find(pid);
                var product = context.Products.Find(pd.ProductId);
                product.AvailablePieces += pd.Quantity;
                context.PurchaseDetails.Remove(pd);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool UpdateUserName(int uno, string name)
        {
            bool status = false;
            try
            {
                var p = context.Users.Find(uno);
                p.UserName = name;
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool UpdateMobileNo(int uno, decimal number)
        {
            bool status = false;
            try
            {
                var p = context.Users.Find(uno);
                p.MobileNumber = number;
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool UpdateAddress(int uno, string address)
        {
            bool status = false;
            try
            {
                var p = context.Users.Find(uno);
                p.Address = address;
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool DeleteProduct(int pid)
        {
            bool status = false;
            bool isPending = false;
            try
            {
                var list = (from p in context.PurchaseDetails
                        where p.ProductId == pid
                        select p).ToList();
                if (list != null) {
                    foreach (var item in list)
                    {
                        if (item.Status.ToLower() == "pending")
                        {
                            isPending = true;
                            break;
                        }
                    }
                }
                if (isPending)
                {
                    status = false;
                }
                else
                {
                    context.PurchaseDetails.RemoveRange(list);
                    context.Products.Remove(context.Products.Find(pid));
                    context.SaveChanges();
                    status = true;
                }
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public Product GetProductByPid(int pid)
        {
            Product product = new Product();
            try
            {
                product = context.Products.Find(pid);
            }
            catch (Exception)
            {

                product = null;
            }
            return product;
        }

        public bool EditProduct(Product product)
        {
            bool status = false;
            try
            {
                var p = context.Products.Find(product.ProductId);
                if(p != null)
                {
                    p.ProductName = product.ProductName;
                    p.Description = product.Description;
                    p.AvailablePieces = product.AvailablePieces;
                    p.PictureFileLocation = product.PictureFileLocation;
                    p.Price = product.Price;
                    p.Discount = product.Discount;
                    context.SaveChanges();
                    status = true;
                }
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool AddNewAdmin(Admin ad)
        {
            bool status = false;
            try
            {
                context.Admins.Add(ad);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
                
            }
            return status;
        }

        public bool AddNewDeliveryMan(DeliveryMan dm)
        {
            bool status = false;
            try
            {
                context.DeliveryMans.Add(dm);
                context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            { 
                status = false;
            }
            return status;
        }

        public List<PurchaseDetail> GetAllPurchaseDetails()
        {
            List<PurchaseDetail> list = new List<PurchaseDetail>();
            try
            {
                list = context.PurchaseDetails.ToList();
            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }

        public bool updateDeliveryStatus(int purchaseId)
        {
            bool status = false;
            try
            {
                var purchaseDetail = context.PurchaseDetails.Find(purchaseId);
                if (purchaseDetail != null)
                {
                    purchaseDetail.Status = "Delivered";
                }
                context.SaveChanges();
                status = true;
            }

            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool DeleteUser(User userObj)
        {
            bool status = false;
            try
            {
                context.Users.Remove(userObj);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        public bool DeleteDeliveryMan(int dmNo)
        {
            bool status = false;
            DeliveryMan deliveryMan = new DeliveryMan();
            try
            {
                deliveryMan = context.DeliveryMans.Find(dmNo);
                context.DeliveryMans.Remove(deliveryMan);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }
    }
}