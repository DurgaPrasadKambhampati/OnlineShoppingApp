﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AkshayaOS.DAL.Models
{
    public partial class AkshayaOSContext : DbContext
    {
        public AkshayaOSContext()
        {
        }

        public AkshayaOSContext(DbContextOptions<AkshayaOSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admins { get; set; } = null!;
        public virtual DbSet<DeliveryMan> DeliveryMans { get; set; } = null!;
        public virtual DbSet<Product> Products { get; set; } = null!;
        public virtual DbSet<PurchaseDetail> PurchaseDetails { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source =(localdb)\\MSSQLLocalDB;Initial Catalog=AkshayaOS;Integrated Security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__Admins__1788CC4C7D2F7923");

                entity.Property(e => e.UserId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.AdminName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(12)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DeliveryMan>(entity =>
            {
                entity.HasKey(e => e.DeliveryManNo)
                    .HasName("PK__Delivery__E33EFA9FE202FAFF");

                entity.HasIndex(e => e.MobileNumber, "UQ__Delivery__250375B110D4F837")
                    .IsUnique();

                entity.HasIndex(e => e.Dmid, "UQ__Delivery__28BFED40FD1B405F")
                    .IsUnique();

                entity.Property(e => e.Dmid)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("DMId");

                entity.Property(e => e.Dmname)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("DMName");

                entity.Property(e => e.MobileNumber).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.Password)
                    .HasMaxLength(12)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PictureFileLocation)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PurchaseDetail>(entity =>
            {
                entity.HasKey(e => e.PurchaseId)
                    .HasName("PK__Purchase__6B0A6BBE0BF5AF66");

                entity.Property(e => e.OrderedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Otp).HasColumnName("OTP");

                entity.Property(e => e.ShippingAddress)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.DeliveryManNoNavigation)
                    .WithMany(p => p.PurchaseDetails)
                    .HasForeignKey(d => d.DeliveryManNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PurchaseD__Deliv__31EC6D26");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.PurchaseDetails)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PurchaseD__Produ__30F848ED");

                entity.HasOne(d => d.UserNoNavigation)
                    .WithMany(p => p.PurchaseDetails)
                    .HasForeignKey(d => d.UserNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PurchaseD__UserN__300424B4");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UserNo)
                    .HasName("PK__Users__1788955FCB8557E0");

                entity.HasIndex(e => e.UserId, "UQ__Users__1788CC4D91F86DAF")
                    .IsUnique();

                entity.HasIndex(e => e.MobileNumber, "UQ__Users__250375B1BA24B5CA")
                    .IsUnique();
                entity.Property(e => e.Address)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.Password)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
