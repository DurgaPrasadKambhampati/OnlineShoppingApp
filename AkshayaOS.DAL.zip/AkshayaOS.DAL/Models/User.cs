﻿using System;
using System.Collections.Generic;

namespace AkshayaOS.DAL.Models
{
    public partial class User
    {
        public User()
        {
            PurchaseDetails = new HashSet<PurchaseDetail>();
        }

        public int UserNo { get; set; }
        public string UserName { get; set; } = null!;
        public string UserId { get; set; } = null!;
        public string Password { get; set; } = null!;
        public decimal MobileNumber { get; set; }

        public string? Address { get; set; }

        public virtual ICollection<PurchaseDetail> PurchaseDetails { get; set; }
    }
}
