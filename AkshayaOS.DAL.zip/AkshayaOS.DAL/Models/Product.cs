﻿using System;
using System.Collections.Generic;

namespace AkshayaOS.DAL.Models
{
    public partial class Product
    {
        public Product()
        {
            PurchaseDetails = new HashSet<PurchaseDetail>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; } = null!;
        public int Price { get; set; }
        public int Discount { get; set; }
        public int AvailablePieces { get; set; }
        public string? PictureFileLocation { get; set; }
        public string? Description { get; set; }

        public virtual ICollection<PurchaseDetail> PurchaseDetails { get; set; }
    }
}
