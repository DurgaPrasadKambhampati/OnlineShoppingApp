﻿using System;
using System.Collections.Generic;

namespace AkshayaOS.DAL.Models
{
    public partial class PurchaseDetail
    {
        public int PurchaseId { get; set; }
        public int UserNo { get; set; }
        public int ProductId { get; set; }
        public int DeliveryManNo { get; set; }
        public int Quantity { get; set; }
        public int TotalAmount { get; set; }
        public DateTime? OrderedDate { get; set; }
        public string? ShippingAddress { get; set; }
        public int Otp { get; set; }
        public string? Status { get; set; }

        public virtual DeliveryMan DeliveryManNoNavigation { get; set; } = null!;
        public virtual Product Product { get; set; } = null!;
        public virtual User UserNoNavigation { get; set; } = null!;
    }
}
