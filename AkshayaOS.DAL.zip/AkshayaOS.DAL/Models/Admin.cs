﻿using System;
using System.Collections.Generic;

namespace AkshayaOS.DAL.Models
{
    public partial class Admin
    {
        public string UserId { get; set; } = null!;
        public string AdminName { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
