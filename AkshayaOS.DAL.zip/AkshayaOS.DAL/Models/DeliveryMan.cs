﻿using System;
using System.Collections.Generic;

namespace AkshayaOS.DAL.Models
{
    public partial class DeliveryMan
    {
        public DeliveryMan()
        {
            PurchaseDetails = new HashSet<PurchaseDetail>();
        }

        public int DeliveryManNo { get; set; }
        public string Dmname { get; set; } = null!;
        public string Dmid { get; set; } = null!;
        public string Password { get; set; } = null!;
        public decimal MobileNumber { get; set; }

        public virtual ICollection<PurchaseDetail> PurchaseDetails { get; set; }
    }
}
