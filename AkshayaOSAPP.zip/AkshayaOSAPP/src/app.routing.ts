import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { ViewProductsComponent } from './app/view-products/view-products.component';
import { AddproductComponent } from './app/addproduct/addproduct.component';
import { CommonLayoutComponent } from './app/common-layout/common-layout.component';
import { UserLoginComponent } from './app/user-login/user-login.component';
import { AdminLoginComponent } from './app/admin-login/admin-login.component';
import { DeliveryManLoginComponent } from './app/delivery-man-login/delivery-man-login.component';
import { UserRegistrationComponent } from './app/user-registration/user-registration.component';
import { PurchaseProductComponent } from './app/purchase-product/purchase-product.component';
import { HomeComponent } from './app/home/home.component';
import { UserViewComponent } from './app/user-view/user-view.component';
import { ViewMyPurchaseDetailsComponent } from './app/view-my-purchase-details/view-my-purchase-details.component';
import { MyProfileComponent } from './app/my-profile/my-profile.component';
import { EditMyDetailsComponent } from './app/edit-my-details/edit-my-details.component';
import { AdminLayoutComponent } from './app/admin-layout/admin-layout.component';
import { ProductListForAdminComponent } from './app/product-list-for-admin/product-list-for-admin.component';
import { EditProductDetailsComponent } from './app/edit-product-details/edit-product-details.component';
import { AddNewAdminComponent } from './app/add-new-admin/add-new-admin.component';
import { AddNewDeliverymanComponent } from './app/add-new-deliveryman/add-new-deliveryman.component';
import { DeliveriesforDMComponent } from './app/deliveriesfor-dm/deliveriesfor-dm.component';
import { ViewUsersComponent } from './app/view-users/view-users.component';
import { ViewDeliveryMansComponent } from './app/view-delivery-mans/view-delivery-mans.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'addDeliveryMan', component: AddNewDeliverymanComponent },
  { path: 'userView', component: UserViewComponent },
  { path: 'userLogin', component: UserLoginComponent },
  { path: 'myPDS', component: ViewMyPurchaseDetailsComponent },
  { path: 'myProfile', component: MyProfileComponent },
  { path: 'editMyDetails', component: EditMyDetailsComponent },
  { path: 'viewProductsAsAdmin', component: ProductListForAdminComponent },
  { path: 'adminLayout', component: AdminLayoutComponent },
  { path: 'editProduct/:productId', component: EditProductDetailsComponent },
  { path: 'commonLayout', component: CommonLayoutComponent },
  { path: 'viewProducts', component: ViewProductsComponent },
  { path: 'addProduct', component: AddproductComponent },
  { path: 'adminLogin', component: AdminLoginComponent },
  { path: 'addAdmin', component: AddNewAdminComponent },
  { path: 'dmLogin', component: DeliveryManLoginComponent },
  { path: 'dmView', component: DeliveriesforDMComponent },
  { path: 'viewUsers', component: ViewUsersComponent },
  { path: 'registerUser', component: UserRegistrationComponent },
  { path: 'viewAllDMs', component: ViewDeliveryMansComponent },
  { path: 'purchaseProduct/:productId/:productName/:productPrice/:discount/:availablePieces', component: PurchaseProductComponent },
  { path: '**', component: ViewProductsComponent }

];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
