import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryManLoginComponent } from './delivery-man-login.component';

describe('DeliveryManLoginComponent', () => {
  let component: DeliveryManLoginComponent;
  let fixture: ComponentFixture<DeliveryManLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryManLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryManLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
