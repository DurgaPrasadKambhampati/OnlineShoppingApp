import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-delivery-man-login',
  templateUrl: './delivery-man-login.component.html',
  styleUrls: ['./delivery-man-login.component.css']
})
export class DeliveryManLoginComponent implements OnInit {
  dmLogin: FormGroup;
  constructor(private formBuilder: FormBuilder, private _productServices: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.dmLogin = this.formBuilder.group({
      dmId: [''],
      password: ['']
    });
  }

  validateDM(form: FormGroup) {
    this._productServices.validateDM(form.value.dmId, form.value.password).subscribe(
      res => {
        if (res != 0) {
          sessionStorage.setItem('dmno', res.toString());
          alert('login is Successfull')
          this.router.navigate(['/dmView']);
        }
        else {
          alert('Something Went Wrong!!')
          this.router.navigate(['/dmLogin'])
        }
      },
      err => { console.log(err); alert('Something Went Wrong') },
      () => { console.log('Validate Delivery Man Completed') }
    )
  }

}
