
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../interfaces/Product';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {
  products: Product[]
  showBuy: boolean = false
  constructor(private _productService: ProductService, private router: Router) { }

  ngOnInit(): void {
    if ("userNo" in sessionStorage) {
      this.showBuy = true;
    }
    this.getProducts();
  }

  getProducts() {
    this._productService.getProducts().subscribe(
      responseProductData => {
        this.products = responseProductData;
      },
      e => { console.log(e.message); },
      () => {console.log('Completeed')}
    );
  }

  PurchaseProduct(product: Product) {
    this.router.navigate(['/purchaseProduct', product.productId, product.productName, product.price, product.discount, product.availablePieces]);
  }

}
