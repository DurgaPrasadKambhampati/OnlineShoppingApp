import { Component, OnInit } from '@angular/core';
import { User } from '../interfaces/User';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  user: User
  constructor(private _services: ProductService) { }

  ngOnInit(): void {
    this._services.getUser(parseInt(sessionStorage.getItem('userNo'))).subscribe(
      res => { this.user = res }
    )
  }

}
