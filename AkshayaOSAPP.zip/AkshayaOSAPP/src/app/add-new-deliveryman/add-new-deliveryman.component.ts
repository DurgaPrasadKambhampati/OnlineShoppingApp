import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { DeliveryMan } from '../interfaces/DeliveryMan';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-add-new-deliveryman',
  templateUrl: './add-new-deliveryman.component.html',
  styleUrls: ['./add-new-deliveryman.component.css'],
})
export class AddNewDeliverymanComponent implements OnInit {
  newdeliveryManForm: FormGroup
  dm: DeliveryMan
  constructor(private builder: FormBuilder, private router: Router, private _services: ProductService) { }

  ngOnInit(): void {
    this.newdeliveryManForm = this.builder.group({
      name: [''],
      dmid: [''],
      password: [''],
      mobileNo:['']
    })
  }
  addDeliveryMan(form: FormGroup) {
    this.dm = { dmid: form.value.dmid, dmname: form.value.name, mobileNumber: form.value.mobileNo, deliveryManNo: 0, password: form.value.password }
    this._services.addDM(this.dm).subscribe(
      res => {
        if (res) {
          alert('Delivery Man Added')
        }
        else {
          alert('User Id already Taken')
        }

      },
      err => { alert('Error Occured!!'); console.log(err) },
      () => { console.log('addDM completed')}
    )
  }
}
