import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewDeliverymanComponent } from './add-new-deliveryman.component';

describe('AddNewDeliverymanComponent', () => {
  let component: AddNewDeliverymanComponent;
  let fixture: ComponentFixture<AddNewDeliverymanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNewDeliverymanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNewDeliverymanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
