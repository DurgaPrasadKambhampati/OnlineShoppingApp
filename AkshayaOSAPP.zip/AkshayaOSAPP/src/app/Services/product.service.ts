import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Product } from '../interfaces/Product';
import { User } from '../interfaces/User';
import { DeliveryMan } from '../interfaces/DeliveryMan';
import { PurchaseDetail } from '../interfaces/PurchaseDetail';
import { parse } from 'querystring';
import { Admin } from '../interfaces/Admin';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  constructor(private http: HttpClient) { }
  getProducts(): Observable<Product[]> {
    
    let tempVar = this.http.get<Product[]>('https://localhost:44310/api/AkshayaOS/GetProducts').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  addProducts(pname: string, price: number, discount: number, avp: number, pfl: string, descri: string): Observable<boolean> {

    var prodObj: Product;
    prodObj = { productId:0, productName: pname, price: price, discount: discount, availablePieces: avp, pictureFileLocation: pfl, description: descri }

    let tempVar = this.http.post<boolean>('https://localhost:44310/api/AkshayaOS/AddProduct',prodObj).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  validateUser(id: string, password: string): Observable<Number> {
    var userObj: User;
    userObj = { userNo: 0, userName: 'hello', userId: id, password: password, mobileNumber: 123, address:'hello' };
    let tempVar = this.http.post<Number>('https://localhost:44310/api/AkshayaOS/ValidateUser', userObj).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  validateDM(id: string, password: string): Observable<Number> {
    var obj: DeliveryMan;
    obj = { deliveryManNo: 0, dmname: 'hello', dmid: id, password: password, mobileNumber: 123 };
    let tempVar = this.http.post<Number>('https://localhost:44310/api/AkshayaOS/ValidateDM', obj).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  validateAdmin(aid: string, pass: string): Observable<boolean> {
    let params = "?aid=" + aid + "&pass=" + pass;
    let tempVar = this.http.get<boolean>('https://localhost:44310/api/AkshayaOS/ValidateAdmin' + params).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  AddUser(name: string, id: string, pass: string, mobileNo: number,addr : string): Observable<boolean> {
    let userObj: User
    userObj = { userNo: 0, userName: name, userId: id, password: pass, mobileNumber: mobileNo, address: addr };
    let tempVar = this.http.post<boolean>('https://localhost:44310/api/AkshayaOS/AddUser',userObj).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  purchaseProduct(pd: PurchaseDetail): Observable<boolean> {
    let tempVar = this.http.post<boolean>('https://localhost:44310/api/AkshayaOS/PurchaseProduct', pd).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getUser(uno: number): Observable<User> {
    let param: string
    param = '?uNo=' + uno
    let tempVar = this.http.get<User>('https://localhost:44310/api/AkshayaOS/GetUserByUserNo' + param).pipe(catchError(this.errorHandler))
    return tempVar;
  }

  getDeliveryMensDetails(): Observable<DeliveryMan[]> {
    let tempVar = this.http.get<DeliveryMan[]>('https://localhost:44310/api/AkshayaOS/GetAllDeliveryMansDetails').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getDMCount(): Observable<number> {
    let tempVar = this.http.get<number>('https://localhost:44310/api/AkshayaOS/GetDMCount').pipe(catchError(this.errorHandler));
    console.log(tempVar)
    return tempVar
  }

  getPurchaseDetailsByUno(uno: number): Observable<PurchaseDetail[]> {
    let tempVar = this.http.get<PurchaseDetail[]>('https://localhost:44310/api/AkshayaOS/GetPurchaseDetailsBYUno?uno='+uno).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  cancleOrder(pid: number): Observable<boolean> {
    let tempVar = this.http.delete<boolean>('https://localhost:44310/api/AkshayaOS/CancleOrder?pid=' + pid).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  updateUname(uname: string): Observable<boolean> {
    let params = new HttpParams().set('uno', sessionStorage.getItem('userNo')).set('uname', uname)
    let body = { title: 'Angular PUT Request Example' };
    let tempVar = this.http.put<boolean>('https://localhost:44310/api/AkshayaOS/UpdateUserName', body, { params: params }).pipe(catchError(this.errorHandler));
    return tempVar
  }

  updateMobileNo(mno: number): Observable<boolean> {
    let params = new HttpParams().set('uno', sessionStorage.getItem('userNo')).set('mobileNumber', mno.toString())
    let body = { title: 'Angular PUT Request Example' };
    let tempVar = this.http.put<boolean>('https://localhost:44310/api/AkshayaOS/UpdateMobileNo', body, { params: params }).pipe(catchError(this.errorHandler));
    return tempVar
  }

  updateAddress(addr: string): Observable<boolean> {
    let params = new HttpParams().set('uno', sessionStorage.getItem('userNo')).set('address', addr)
    let body = { title: 'Angular PUT Request Example' };
    let tempVar = this.http.put<boolean>('https://localhost:44310/api/AkshayaOS/UpadateAddress', body, { params: params }).pipe(catchError(this.errorHandler));
    return tempVar
  }

  deleteProduct(pid: number): Observable<boolean> {
    let tempVar = this.http.delete<boolean>('https://localhost:44310/api/AkshayaOS/DeleteProduct?pid=' + pid).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getProductByPid(pid: number): Observable<Product>{
    let tempVar = this.http.get<Product>('https://localhost:44310/api/AkshayaOS/GetProductByPid?pid=' + pid).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  editProdct(product: Product): Observable<boolean> {
    let tempVar = this.http.put<boolean>('https://localhost:44310/api/AkshayaOS/EditProduct', product).pipe(catchError(this.errorHandler));
    return tempVar
  }

  addAdmin(admin: Admin): Observable<boolean> {
    let tempVar = this.http.post<boolean>('https://localhost:44310/api/AkshayaOS/AddAdmin', admin).pipe(catchError(this.errorHandler));
    return tempVar
  }

  addDM(dm: DeliveryMan): Observable<boolean> {
    let tempVar = this.http.post<boolean>('https://localhost:44310/api/AkshayaOS/AddNewDeliveryMan', dm).pipe(catchError(this.errorHandler));
    return tempVar
  }

  getPurchaseDetailsBydmno(dmno: number): Observable<PurchaseDetail[]> {
    let tempVar = this.http.get<PurchaseDetail[]>('https://localhost:44310/api/AkshayaOS/GetPurchaseDetailsByDMno?dmno=' + dmno).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  updateStatus(pid: number): Observable<boolean> {
    let params = new HttpParams().set('pid', pid.toString())
    let body = { title: 'Angular PUT Request Example' };
    let tempVar = this.http.put<boolean>('https://localhost:44310/api/AkshayaOS/updateDeliveryStatus', body, { params: params }).pipe(catchError(this.errorHandler));
    return tempVar
  }

  getAllUsers(): Observable<User[]> {
    let tempvar = this.http.get<User[]>('https://localhost:44310/api/AkshayaOS/GetAllUsers').pipe(catchError(this.errorHandler));
    return tempvar;
  }

  deleteUser(user: User): Observable<boolean>{
    let httpOptions = { headers: new HttpHeaders({ 'accept': '*/*' , 'Content-Type': 'application/json'}), body: user };
    let tempVar = this.http.delete<boolean>('https://localhost:44310/api/AkshayaOS/DeleteUser', httpOptions).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  deleteDeliveryMan(dmno: number): Observable<boolean> {
    let tempVar = this.http.delete<boolean>('https://localhost:44310/api/AkshayaOS/DeleteDeliveryMan?dmNo=' + dmno).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}
