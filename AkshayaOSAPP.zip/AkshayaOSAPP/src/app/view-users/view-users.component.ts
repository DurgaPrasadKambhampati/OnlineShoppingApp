import { Component, OnInit } from '@angular/core';
import { User } from '../interfaces/User';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.css']
})
export class ViewUsersComponent implements OnInit {
  users: User[]
  constructor(private _services: ProductService) { }

  ngOnInit(): void {
    this._services.getAllUsers().subscribe(
      res => { this.users = res })
  }

  DeleteUser(user: User) {
    this._services.deleteUser(user).subscribe(
      (res) => {
        if (res) {
          alert('User Deleted');
        }
        else {
          alert('User Not Deleted');
        }
      },
      err => { alert('Error Occured While Deleting the user'); console.log(err) },
      () => {}
    )
  }

}
