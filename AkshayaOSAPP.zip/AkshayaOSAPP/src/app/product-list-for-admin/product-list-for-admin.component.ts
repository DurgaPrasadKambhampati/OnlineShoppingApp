import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../interfaces/Product';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-product-list-for-admin',
  templateUrl: './product-list-for-admin.component.html',
  styleUrls: ['./product-list-for-admin.component.css']
})
export class ProductListForAdminComponent implements OnInit {
  products: Product[]
  constructor(private _services: ProductService, private router: Router) { }

  ngOnInit(): void {
    this._services.getProducts().subscribe(
      res => { this.products = res }
    );
  }
  DeleteProduct(pid: number) {
    this._services.deleteProduct(pid).subscribe(
      res => {
        if (res) {
          alert('Product Deleted')
        }
        else {
          alert('Sorry For Inconvinience,Product Not Deleted!!')
        }
      }
    )
  }
  EditProduct(product: Product) {
    this.router.navigate(['/editProduct', product.productId])
  }
}
