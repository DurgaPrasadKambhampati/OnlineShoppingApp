import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-edit-my-details',
  templateUrl: './edit-my-details.component.html',
  styleUrls: ['./edit-my-details.component.css']
})
export class EditMyDetailsComponent implements OnInit {

  editUserName: FormGroup;
  editMobileNo: FormGroup;
  editAddress: FormGroup;
  constructor(private formBuilder: FormBuilder, private _productServices: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.editMobileNo = this.formBuilder.group({
      mobileNo: ['']
    });
    this.editUserName = this.formBuilder.group({
      userName: [''],
    });
    this.editAddress = this.formBuilder.group(
      {
        address: ['']
      });
  }

  updateUserName(form: FormGroup) {
    console.log(form.value.userName)
    this._productServices.updateUname(form.value.userName).subscribe(
      res => {
        if (res) {
          alert('Successfully Updated')
          this.router.onSameUrlNavigation;
        }
        else
          alert('somthing Went Wrong!!')
        
      },
      err => {
        console.log(err)
      },
      () => {}
    )
  }

  updateMobileNo(form: FormGroup) {
    this._productServices.updateMobileNo(form.value.mobileNo).subscribe(
      res => {
        if (res) {
          alert('Successfully Updated')
          this.router.onSameUrlNavigation;
        }
        else
          alert('somthing Went Wrong!!')

      },
      err => {
        console.log(err)
      },
      () => { }
    )
  }

  updateAddress(form: FormGroup) {
    this._productServices.updateAddress(form.value.address).subscribe(
      res => {
        if (res) {
          alert('Successfully Updated')
          this.router.onSameUrlNavigation;
        }
        else
          alert('somthing Went Wrong!!')

      },
      err => {
        console.log(err)
      },
      () => { }
    )
  }
}

