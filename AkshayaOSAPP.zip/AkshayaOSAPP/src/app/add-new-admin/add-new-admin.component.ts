import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Admin } from '../interfaces/Admin';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-add-new-admin',
  templateUrl: './add-new-admin.component.html',
  styleUrls: ['./add-new-admin.component.css']
})
export class AddNewAdminComponent implements OnInit {
  newAdmin: FormGroup
  admin: Admin
  constructor(private _services: ProductService, private builder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.newAdmin = this.builder.group({
      adminName: [''],
      userId: [''],
      password:['']
    })
  }

  addNewAdmin(form: FormGroup) {
    this.admin = { adminName: form.value.adminName, userId: form.value.userId, password: form.value.password }
    this._services.addAdmin(this.admin).subscribe(
      res => {
        if (res) {
          alert('Admin Successfully Added..')
        }
        else {
          alert('User Id already Taken,Please choose another')
        }
      },
      err => { alert('error occured'); console.log(err) },
      () => { console.log('add admin completed') }
    )
  }

}
