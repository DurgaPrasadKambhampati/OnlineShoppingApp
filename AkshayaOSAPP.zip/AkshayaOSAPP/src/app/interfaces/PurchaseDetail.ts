
export interface PurchaseDetail {
  purchaseId: number
  userNo: number
  productId: number
  deliveryManNo: number
  quantity: number
  totalAmount: number
  orderDate: Date
  shippingAddress: string
  otp: number
  status: string
}
