

export interface DeliveryMan {
  deliveryManNo: number
  dmname: string
  dmid: string
  password: string
  mobileNumber: number
}
