export interface User {
  userNo: number
  userName: string
  userId: string
  password: string
  mobileNumber: number
  address :string
}
