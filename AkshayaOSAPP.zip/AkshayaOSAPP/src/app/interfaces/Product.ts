export interface Product {
  productId: number
  productName: string
  price: number
  discount: number
  availablePieces: number
  pictureFileLocation: string
  description: string
}
