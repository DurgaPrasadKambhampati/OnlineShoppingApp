export interface Admin {
  userId: string
  adminName: string
  password: string
}
