import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliverymanLayoutComponent } from './deliveryman-layout.component';

describe('DeliverymanLayoutComponent', () => {
  let component: DeliverymanLayoutComponent;
  let fixture: ComponentFixture<DeliverymanLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliverymanLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliverymanLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
