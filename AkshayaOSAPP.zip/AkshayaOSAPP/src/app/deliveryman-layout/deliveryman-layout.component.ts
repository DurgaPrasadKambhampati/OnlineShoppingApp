import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deliveryman-layout',
  templateUrl: './deliveryman-layout.component.html',
  styleUrls: ['./deliveryman-layout.component.css']
})
export class DeliverymanLayoutComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  LogOut() {
    sessionStorage.removeItem('dmno');
    this.router.navigate(['/home']);
  }
}
