import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ProductService } from '../Services/product.service';


@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  addProdForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private _productServices: ProductService) { }

  ngOnInit(): void {
    this.addProdForm = this.formBuilder.group({
      pName: [''],
      price: [''],
      discount: [''],
      apieces: [''],
      pfl: [''],
      desc:['']
    });
  }

  SubmitForm(form: FormGroup) {
    this._productServices.addProducts(form.value.pName, form.value.price, form.value.discount, form.value.apieces, form.value.pfl, form.value.desc).subscribe(
      resp => {
        if (resp) {
          alert('Product Added Successfully')
        }
        else {
          alert('Something went wrong!!')
        }
      },
      er => {
        console.log(er)
        alert('Something went wrong!!!')
      },
      () => {console.log('addProduct completed')}
    )
  }

}
