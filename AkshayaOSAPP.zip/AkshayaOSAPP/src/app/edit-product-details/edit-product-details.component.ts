import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../interfaces/Product';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-edit-product-details',
  templateUrl: './edit-product-details.component.html',
  styleUrls: ['./edit-product-details.component.css']
})
export class EditProductDetailsComponent implements OnInit {
  productId: number
  product: Product
  modifiedProduct: Product
  editProductForm: FormGroup
  constructor(private route: ActivatedRoute, private router: Router, private _services: ProductService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.editProductForm = this.formBuilder.group({
      pname: [''],
      price: [''],
      discount: [''],
      availablePieces: [''],
      description: [''],
    })
    this.productId = parseInt(this.route.snapshot.params['productId']);
    this._services.getProductByPid(this.productId).subscribe(
      res => { this.product = res },
      err => { console.log('product not fetched') },
      () => {}
    );
    
  }

  EditProduct(form: FormGroup) {
    this.modifiedProduct = {
      productId: this.productId,
      productName: form.value.pname,
      price: form.value.price,
      discount: form.value.discout,
      description: form.value.description,
      availablePieces: form.value.availablePieces,
      pictureFileLocation: this.product.pictureFileLocation
    }
    this._services.editProdct(this.modifiedProduct).subscribe(
      res => {
        if (res) {
          alert('Product Edited Successfully');
          this.router.navigate(['/viewProductsAsAdmin'])
        }
        else {
          alert('Details are not Updated!')
          this.router.navigate(['/viewProductsAsAdmin'])
        }
      },
      err => { alert('error Occured!!'), console.log(err) },
      () => { console.log('editProduct Completed') }
    )
  }

}
