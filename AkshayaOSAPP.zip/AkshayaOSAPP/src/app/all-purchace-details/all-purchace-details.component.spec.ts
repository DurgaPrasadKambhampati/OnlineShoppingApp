import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllPurchaceDetailsComponent } from './all-purchace-details.component';

describe('AllPurchaceDetailsComponent', () => {
  let component: AllPurchaceDetailsComponent;
  let fixture: ComponentFixture<AllPurchaceDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllPurchaceDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllPurchaceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
