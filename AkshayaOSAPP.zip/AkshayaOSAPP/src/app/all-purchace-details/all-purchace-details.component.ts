import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-purchace-details',
  templateUrl: './all-purchace-details.component.html',
  styleUrls: ['./all-purchace-details.component.css']
})
export class AllPurchaceDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
