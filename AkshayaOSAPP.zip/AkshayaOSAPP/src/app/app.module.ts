import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { ProductService } from './Services/product.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routing } from '../app.routing';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AddproductComponent } from './addproduct/addproduct.component';
import { CommonLayoutComponent } from './common-layout/common-layout.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { DeliveryManLoginComponent } from './delivery-man-login/delivery-man-login.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { PurchaseProductComponent } from './purchase-product/purchase-product.component';
import { UserViewComponent } from './user-view/user-view.component';
import { HomeComponent } from './home/home.component';
import { ViewMyPurchaseDetailsComponent } from './view-my-purchase-details/view-my-purchase-details.component';
import { UserLayoutComponent } from './user-layout/user-layout.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { EditMyDetailsComponent } from './edit-my-details/edit-my-details.component';
import { AdminLayoutComponent } from './admin-layout/admin-layout.component';
import { ProductListForAdminComponent } from './product-list-for-admin/product-list-for-admin.component';
import { EditProductDetailsComponent } from './edit-product-details/edit-product-details.component';
import { AddNewAdminComponent } from './add-new-admin/add-new-admin.component';
import { AddNewDeliverymanComponent } from './add-new-deliveryman/add-new-deliveryman.component';
import { AllPurchaceDetailsComponent } from './all-purchace-details/all-purchace-details.component';
import { DeliveriesforDMComponent } from './deliveriesfor-dm/deliveriesfor-dm.component';
import { DeliverymanLayoutComponent } from './deliveryman-layout/deliveryman-layout.component';
import { ViewUsersComponent } from './view-users/view-users.component';
import { ViewDeliveryMansComponent } from './view-delivery-mans/view-delivery-mans.component';



@NgModule({
  declarations: [
    AppComponent,
    ViewProductsComponent,
    AddproductComponent,
    CommonLayoutComponent,
    UserLoginComponent,
    AdminLoginComponent,
    DeliveryManLoginComponent,
    UserRegistrationComponent,
    PurchaseProductComponent,
    UserViewComponent,
    HomeComponent,
    ViewMyPurchaseDetailsComponent,
    UserLayoutComponent,
    MyProfileComponent,
    EditMyDetailsComponent,
    AdminLayoutComponent,
    ProductListForAdminComponent,
    EditProductDetailsComponent,
    AddNewAdminComponent,
    AddNewDeliverymanComponent,
    AllPurchaceDetailsComponent,
    DeliveriesforDMComponent,
    DeliverymanLayoutComponent,
    ViewUsersComponent,
    ViewDeliveryMansComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, ReactiveFormsModule, routing,
    HttpClientModule,
  ],
  providers: [ProductService, HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
