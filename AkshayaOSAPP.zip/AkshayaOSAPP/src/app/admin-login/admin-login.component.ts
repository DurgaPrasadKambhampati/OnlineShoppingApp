import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  adminLogin: FormGroup;
  constructor(private formBuilder: FormBuilder, private _productServices: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.adminLogin = this.formBuilder.group({
      aId: [''],
      pass: ['']
    });
  }

  validateAdmin(form: FormGroup) {
    this._productServices.validateAdmin(form.value.aId, form.value.pass).subscribe(
      res => {
        if (res) {
          sessionStorage.setItem('adminId', form.value.aId);
          alert('login is Successfull')
          this.router.navigate(['/viewProductsAsAdmin']);
        }
        else {
          alert('Credantials are not Matched')
          this.router.navigate(['/adminLogin'])
        }
      },
      err => { console.log(err); alert('Something Went Wrong') },
      () => { console.log('Validate Admin Completed') }
    )
  }
}
