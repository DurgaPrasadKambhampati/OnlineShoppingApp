import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PurchaseDetail } from '../interfaces/PurchaseDetail';
import { ProductService } from '../Services/product.service';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-view-my-purchase-details',
  templateUrl: './view-my-purchase-details.component.html',
  styleUrls: ['./view-my-purchase-details.component.css']
})
export class ViewMyPurchaseDetailsComponent implements OnInit {

  PurchaseDetails: PurchaseDetail[]
  uno: number
  datePipe: DatePipe = new DatePipe('en-US')

  constructor(private _services: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.uno = parseInt(sessionStorage.getItem('userNo'))
    this._services.getPurchaseDetailsByUno(this.uno).subscribe(
      res => { this.PurchaseDetails = res; }
    )
  }

  cancleOrder(pid: number) {
    this._services.cancleOrder(pid).subscribe(
      res => {
        if (res) {
          alert('Your Order Cancled')
        }
        else {
          alert('Something Went Wrong!!')
        }
        this.router.getCurrentNavigation();
      },
      err => { console.log(err); alert('Error Occured while Cancling the Order') },
      () => {console.log('cancleOrder is Completed')}
    )
  }

  
}
