import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMyPurchaseDetailsComponent } from './view-my-purchase-details.component';

describe('ViewMyPurchaseDetailsComponent', () => {
  let component: ViewMyPurchaseDetailsComponent;
  let fixture: ComponentFixture<ViewMyPurchaseDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMyPurchaseDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMyPurchaseDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
