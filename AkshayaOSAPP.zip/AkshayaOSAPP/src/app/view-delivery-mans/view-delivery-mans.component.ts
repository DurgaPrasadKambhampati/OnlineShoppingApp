import { Component, OnInit } from '@angular/core';
import { DeliveryMan } from '../interfaces/DeliveryMan';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-view-delivery-mans',
  templateUrl: './view-delivery-mans.component.html',
  styleUrls: ['./view-delivery-mans.component.css']
})
export class ViewDeliveryMansComponent implements OnInit {
  dms: DeliveryMan[]
  constructor(private _services: ProductService) { }

  ngOnInit(): void {
    this._services.getDeliveryMensDetails().subscribe(res => { this.dms = res });
  }
  DeleteUser(dm: DeliveryMan) {
    this._services.deleteDeliveryMan(dm.deliveryManNo).subscribe(
      res => {
        if (res) {
          alert('Delivery Man Deleted')
        }
        else {
          alert('Not Deleted')
        }
      },
      err => { alert('Error Occured!!'); console.log(err) },
      () => {}
    )
  }
}
