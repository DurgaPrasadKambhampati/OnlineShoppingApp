import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDeliveryMansComponent } from './view-delivery-mans.component';

describe('ViewDeliveryMansComponent', () => {
  let component: ViewDeliveryMansComponent;
  let fixture: ComponentFixture<ViewDeliveryMansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDeliveryMansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDeliveryMansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
