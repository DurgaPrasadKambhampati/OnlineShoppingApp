import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../interfaces/Product';
import { PurchaseDetail } from '../interfaces/PurchaseDetail';
import { User } from '../interfaces/User';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-purchase-product',
  templateUrl: './purchase-product.component.html',
  styleUrls: ['./purchase-product.component.css']
})
export class PurchaseProductComponent implements OnInit {
  purchaseDetails: PurchaseDetail
  user: User
  userNo: number
  totalAmount: number
  dmNo: number
  quantity: number
  productId: number
  productPrice: number
  ap: number
  discount: number
  productName : string

  constructor(private route: ActivatedRoute, private _productServices: ProductService, private router: Router) {
    
  }

  ngOnInit(): void {
    
    this.productId = parseInt(this.route.snapshot.params['productId'])
    this.productName = this.route.snapshot.params['productName']
    this.productPrice = parseInt(this.route.snapshot.params['productPrice'])
    this.discount = parseInt(this.route.snapshot.params['discount'])
    this.ap =parseInt( this.route.snapshot.params['availablePieces'])
    this.userNo = parseInt(sessionStorage.getItem('userNo'))
    this._productServices.getUser(this.userNo).subscribe(
      res => { this.user = res; },
      err => { console.log(err) },
      () => { }
    );
    this._productServices.getDMCount().subscribe(
      res => {
        this.dmNo = Math.floor(Math.random() + res - 1) + 1;
      }
    );
  }

  purchase(qty : number) {
    this.purchaseDetails = {
      purchaseId: 0,
      productId: this.productId,
      userNo: this.userNo,
      deliveryManNo: this.dmNo,
      quantity: qty,
      totalAmount: qty * (this.productPrice / 100) * (100 - this.discount),
      orderDate: new Date(),
      shippingAddress: this.user.address,
      otp: Math.floor(Math.random() * 900000) + 10000,
      status: 'Pending'
    };
    this._productServices.purchaseProduct(this.purchaseDetails).subscribe(
      res => {
        if (res) {
          alert('product purchase successful')
          this.router.navigate(['/myPDS'])
        }
        else {
          alert('something went wrong!!')
        }
      },
      err => {
        alert('error occured!'),
          console.log(err)

      },
      () => { console.log('Purchase Product completed') }
    )
    
  }

}
