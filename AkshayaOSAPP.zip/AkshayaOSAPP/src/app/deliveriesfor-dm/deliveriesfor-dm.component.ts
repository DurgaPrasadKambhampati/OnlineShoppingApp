import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PurchaseDetail } from '../interfaces/PurchaseDetail';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-deliveriesfor-dm',
  templateUrl: './deliveriesfor-dm.component.html',
  styleUrls: ['./deliveriesfor-dm.component.css']
})
export class DeliveriesforDMComponent implements OnInit {
  PurchaseDetails: PurchaseDetail[]
  showInput: boolean = false
  checkingSecurityCode: FormGroup
  otp: number = 0
  pid : number = 0
  constructor(private _services: ProductService, private builder: FormBuilder) { }

  ngOnInit(): void {
    this._services.getPurchaseDetailsBydmno(parseInt(sessionStorage.getItem('dmno'))).subscribe(
      res => {
        this.PurchaseDetails = res
      }
    );
    this.checkingSecurityCode = this.builder.group(
      { otp: [''] }
    )
  }
  updateStatus(pid: number,otp: number) {
    this.pid = pid
    this.otp = otp
    this.showInput = true
  }
  checkandUpdate(form: FormGroup) {
    if (form.value.otp != this.otp) {
      alert('Incorrect OTP!!')
    }
    else {
      this._services.updateStatus(this.pid).subscribe(
        res => { alert('otp is correct. collect the money and delivery it to porson') }
      )
    }
  }
}
