import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveriesforDMComponent } from './deliveriesfor-dm.component';

describe('DeliveriesforDMComponent', () => {
  let component: DeliveriesforDMComponent;
  let fixture: ComponentFixture<DeliveriesforDMComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveriesforDMComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveriesforDMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
