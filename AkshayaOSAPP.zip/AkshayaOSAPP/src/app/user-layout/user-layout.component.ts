import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-user-layout',
  templateUrl: './user-layout.component.html',
  styleUrls: ['./user-layout.component.css']
})
export class UserLayoutComponent implements OnInit {

  userName : string

  constructor(private router: Router, private _services: ProductService) { }

  ngOnInit(): void {
    this._services.getUser(parseInt(sessionStorage.getItem('userNo'))).subscribe(
      res => { this.userName = res.userName }
    )
  }
  LogOut() {
    sessionStorage.removeItem('userNo');
    this.router.navigate['/home'];
  }
}
