import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  registerUser: FormGroup;
  constructor(private formBuilder: FormBuilder, private _productServices: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.registerUser = this.formBuilder.group({
      userName :[''],
      userId: [''],
      password: [''],
      mobileNo: [''],
      address:['']
    });
  }
  addUser(form: FormGroup) {
    this._productServices.AddUser(form.value.userName, form.value.userId, form.value.password, form.value.mobileNo, form.value.address).subscribe(
      res => {
        if (res) {
          alert('Registration is Successfull')
          this.router.navigate(['/userLogin']);
        }
        else {
          alert('Something Went Wrong!!')
          this.router.navigate(['/registerUser'])
        }
      },
      err => { console.log(err); alert('Something Went Wrong') },
      () => { console.log('User Registration Completed') }
    )
  }
}
