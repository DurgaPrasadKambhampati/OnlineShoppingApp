import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../Services/product.service';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  userLogin: FormGroup;

  constructor(private formBuilder: FormBuilder, private _productServices: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.userLogin = this.formBuilder.group({
      userId: [''],
      password: ['']
    });
  }

  validateUser(form: FormGroup) {
    this._productServices.validateUser(form.value.userId, form.value.password).subscribe(
      res => {
        if (res != 0) {
          sessionStorage.setItem('userNo', res.toString());
          alert('login is Successfull')
          this.router.navigate(['/userView']);
        }
        else {
          alert('Your Credantials are Not Matches!!')
          this.router.navigate(['/userLogin'])
        }
      },
      err => { console.log(err);alert('Something Went Wrong') },
      () => {console.log('Validate User Completed')}
    )
  }

}
